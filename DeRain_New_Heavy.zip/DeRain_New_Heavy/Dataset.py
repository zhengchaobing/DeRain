import torch
import torchvision
from torch.utils import data
from torch.autograd import Variable
import cv2
import numpy as np
import os
import random

from glob import glob

train_len=1800
class DatasetTrain(data.Dataset):

    def __init__(self, opt):
        MidRoot  = np.array([''])
        HigRoot  = np.array([''])

        # for file in os.listdir(opt.test_root):
        for index in range(1, train_len + 1):
            file = str(index)
            MidRoot  = np.append(MidRoot,  opt.train_rootM + file + '.png')
            HigRoot  = np.append(HigRoot,  opt.train_rootH + file + '.png')

        self.MidRoot = MidRoot[1:]
        self.HigRoot = HigRoot[1:]

        self.opt = opt
        self.len = train_len

    def transformImage(self,image):
        opt = self.opt
        image = torchvision.transforms.ToTensor()(image)
        Tensor = torch.FloatTensor if opt.device == 'cpu' else torch.cuda.FloatTensor
        image = Variable(image.type(Tensor))
        return image

    def WeightMax(self,weight):
        weight_copy = weight.clone()
        weight_copy[0, :, :] = torch.max(weight,dim=0)[0]
        weight_copy[1, :, :] = torch.max(weight,dim=0)[0]
        weight_copy[2, :, :] = torch.max(weight,dim=0)[0]
        return weight_copy

    def WeightMin(self,weight):
        weight_copy = weight.clone()
        weight_copy[0, :, :] = torch.min(weight,dim=0)[0]
        weight_copy[1, :, :] = torch.min(weight,dim=0)[0]
        weight_copy[2, :, :] = torch.min(weight,dim=0)[0]
        return weight_copy

    def WeightBinaryL(self, image, lamda=5.0):
        weight = image.copy()
        weight[:,:,:] = 1.0
        upper_bound = 255.0 - lamda
        weight[image > upper_bound] = 0.0

        weight = torch.from_numpy(weight)
        weight = weight.permute([2, 0, 1])
        Tensor = torch.FloatTensor if self.opt.device == 'cpu' else torch.cuda.FloatTensor
        weight = Variable(weight.type(Tensor))

        weight = self.WeightMin(weight)
        return weight

    def WeightBinaryH(self, image, lamda=5):
        weight = image.copy()
        weight[:,:,:] = 1.0
        lower_bound = 0.0 + lamda
        weight[image < lower_bound] = 0.0

        weight = torch.from_numpy(weight)
        weight = weight.permute([2, 0, 1])
        Tensor = torch.FloatTensor if self.opt.device == 'cpu' else torch.cuda.FloatTensor
        weight = Variable(weight.type(Tensor))

        weight = self.WeightMin(weight)
        return weight

    def __getitem__(self, index):
        W = 128
        H = 128

        img_Rain  = cv2.imread(self.MidRoot[index])
        Hig, Wid, C = img_Rain.shape

        w_offset = random.randint(0, max(0, Wid - W - 1))
        h_offset = random.randint(0, max(0, Hig - H - 1))

        mid = cv2.imread(self.MidRoot[index])[h_offset:h_offset + H, w_offset:w_offset + W, :]
        hig = cv2.imread(self.HigRoot[index]) [h_offset:h_offset + H, w_offset:w_offset + W, :]

        mid = self.transformImage(mid)
        hig = self.transformImage(hig)
        return mid, hig

    def __len__(self):
        return int(self.len)

test_len=200
class DatasetTest(data.Dataset):
        def __init__(self, opt):
            MidRoot = np.array([''])
            HigRoot = np.array([''])
            # for file in os.listdir(opt.test_root):
            for index in range(1, test_len + 1):
                file = str(index)
                HigRoot = np.append(HigRoot, opt.test_rootH + file + '.png')
                MidRoot = np.append(MidRoot, opt.test_rootM + file + '.png')

            self.MidRoot  = MidRoot[1:]
            self.HigRoot  = HigRoot[1:]
            self.opt = opt


        def transformImage(self, image):
            opt = self.opt
            image = torchvision.transforms.ToTensor()(image)
            Tensor = torch.FloatTensor if opt.device == 'cpu' else torch.cuda.FloatTensor
            image = Variable(image.type(Tensor))
            return image

        def WeightMax(self, weight):
            weight_copy = weight.clone()
            weight_copy[0, :, :] = torch.max(weight, dim=0)[0]
            weight_copy[1, :, :] = torch.max(weight, dim=0)[0]
            weight_copy[2, :, :] = torch.max(weight, dim=0)[0]
            return weight_copy

        def WeightMin(self, weight):
            weight_copy = weight.clone()
            weight_copy[0, :, :] = torch.min(weight, dim=0)[0]
            weight_copy[1, :, :] = torch.min(weight, dim=0)[0]
            weight_copy[2, :, :] = torch.min(weight, dim=0)[0]
            return weight_copy

        def WeightBinaryL(self, image, lamda=5):
            weight = image.copy()
            weight[:, :, :] = 1.0
            upper_bound = 255 - lamda
            weight[image > upper_bound] = 0.0

            weight = torch.from_numpy(weight)
            weight = weight.permute([2, 0, 1])
            Tensor = torch.FloatTensor if self.opt.device == 'cpu' else torch.cuda.FloatTensor
            weight = Variable(weight.type(Tensor))

            weight = self.WeightMin(weight)
            return weight

        def WeightBinaryH(self, image, lamda=5):
            weight = image.copy()
            weight[:, :, :] = 1.0
            lower_bound = 0.0 + lamda
            weight[image < lower_bound] = 0.0

            weight = torch.from_numpy(weight)
            weight = weight.permute([2, 0, 1])
            Tensor = torch.FloatTensor if self.opt.device == 'cpu' else torch.cuda.FloatTensor
            weight = Variable(weight.type(Tensor))

            weight = self.WeightMin(weight)
            return weight


        def __getitem__(self, index):
            mid = cv2.imread(self.MidRoot[index])
            hig = cv2.imread(self.HigRoot[index])

            mid = self.transformImage(mid)
            hig  = self.transformImage(hig)
            return mid, hig

        def __len__(self):
            return test_len
