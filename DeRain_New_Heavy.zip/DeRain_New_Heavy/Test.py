# python相关
import os
import warnings
# pytorh相关
import torch
from torch.utils import data
import numpy as np
# 自定义类
from config import get_arguments
import Dataset
import SavePicture
import IMF
import skimage
import time
#忽视警告
warnings.filterwarnings("ignore")

# 导入参数设置
parser = get_arguments()
opt = parser.parse_args()

torch.manual_seed(opt.seed)
if opt.cuda:
    torch.cuda.manual_seed(opt.seed)
#并行训练相关设置
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device=torch.device("cuda:0")

#读取数据集

test_dataset  = Dataset.DatasetTest(opt)
batch_test  = 1
test_loader  = data.DataLoader(dataset=test_dataset,  batch_size=batch_test,  shuffle=False,)


model_path = "checkpoint/{}/netG_model_epoch_{}.pth".format(opt.dataset, opt.nepochs)
net_g = torch.load(model_path).to(device)

net_g.eval()
with torch.no_grad():
    tic = time.perf_counter()
    for idx, (Rain, DeRain) in enumerate(test_loader):
        Rain_fft = torch.fft.fft2(Rain, dim=(-2, -1))
        Rain_amp = torch.abs(Rain_fft)
        Rain_phase = torch.angle(Rain_fft)
        output = net_g(Rain, Rain_amp, Rain_phase)[1]
    print('finished in {} seconds'.format((time.perf_counter() - tic) / 200))
