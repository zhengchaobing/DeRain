# python相关
import cv2
import os
import sys
import platform
import time
import itertools
import numpy as np
import warnings
import argparse
from test_Demo import DeRainNet, DeRainNet2, DeRainNet3
# pytorh相关
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torch.nn.functional as F
from torch.utils import data
from torch.utils.data import DataLoader
from torch.autograd import Variable
import torch.distributed as dist
from torch.utils.checkpoint import checkpoint_sequential
from utils import save_img,calculate_0_distance,calculate_2_distance
from skimage.metrics import peak_signal_noise_ratio as compare_psnr
from skimage.metrics import structural_similarity as compare_ssim
# 自定义类
from config import get_arguments
import Dataset
import SavePicture
from networks import Enhance, get_scheduler, update_learning_rate
from utils import calculate_cos_distance,calculate_L1_L2_distance
#忽视警告
warnings.filterwarnings("ignore")
import random

import imageio
imageio.core.util.appdata_dir("imageio")


# 导入参数设置
parser = get_arguments()
opt = parser.parse_args()

torch.manual_seed(opt.seed)
if opt.cuda:
    torch.cuda.manual_seed(opt.seed)
#并行训练相关设置
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device0=torch.device("cuda:0")

#读取数据集
train_dataset = Dataset.DatasetTrain(opt)
test_dataset  = Dataset.DatasetTest(opt)

batch_train = 6
batch_test  = 1
train_loader = data.DataLoader(dataset=train_dataset, batch_size=batch_train, shuffle=True,)
test_loader  = data.DataLoader(dataset=test_dataset,  batch_size=batch_test,  shuffle=False,)

step=1
model_path_L2H ="checkpoint/{}/netG_model_epoch_{}.pth".format(opt.dataset, opt.nepochs)
print('===> Building models')
model_restoration = DeRainNet()
model_restoration = torch.nn.DataParallel(model_restoration)

if os.path.exists(model_path_L2H):
    print('===> Success load model_L2H models')
    model_restoration  = torch.load(model_path_L2H)
    opt.epoch_count=opt.nepochs+1
model_restoration.to(torch.device('cuda'))


criterionL1  = nn.L1Loss().to(device0)
# setup optimizer
optimizer_g = optim.Adam(model_restoration.parameters(), lr=opt.lr, betas=(opt.beta1, 0.999))
net_g_scheduler = get_scheduler(optimizer_g, opt)

a = [];
b = [];
c = [];
if os.path.exists('./Log/a.npy'):
    a = np.load("./Log/a.npy").tolist()
if os.path.exists('./Log/b.npy'):
    b = np.load("./Log/b.npy").tolist()
if os.path.exists('./Log/c.npy'):
    c = np.load("./Log/c.npy").tolist()

for epoch in range(opt.epoch_count, opt.niter + opt.niter_decay + 1):
    # train
    model_restoration.train()
    for idx ,(mid,  hig) in enumerate(train_loader):
        Rain_fft = torch.fft.fft2(mid, dim=(-2, -1))
        Rain_amp = torch.abs(Rain_fft)
        Rain_phase = torch.angle(Rain_fft)

        optimizer_g.zero_grad()
        Fake_M = model_restoration(mid, Rain_amp, Rain_phase)
        n_levels = 2

        loss = 0
        for level in range(n_levels):
            scale = 0.5
            scale = scale ** (n_levels - level - 1)
            n, c1, h, w = mid.shape
            hi = int(round(h * scale))
            wi = int(round(w * scale))
            sharp_level = F.interpolate(hig, (hi, wi), mode='bilinear')

            train_out_J_fft = torch.fft.fft2(sharp_level, dim=(-2, -1))
            train_out_J_fft2 = torch.stack((train_out_J_fft.real, train_out_J_fft.imag), -1)
            train_labels_fft = torch.fft.fft2(Fake_M[level], dim=(-2, -1))
            train_labels_fft2 = torch.stack((train_labels_fft.real, train_labels_fft.imag), -1)

            loss = loss + criterionL1(sharp_level, Fake_M[level]) + criterionL1(train_out_J_fft2, train_labels_fft2) * 0.01
        loss.backward()
        optimizer_g.step()
        print("===> Epoch[{}]({}/{}): Loss: {:.4f} Loss1: {:.4f} ".format(epoch,idx, len(train_loader),loss.item(), loss.item()))
    update_learning_rate(net_g_scheduler, optimizer_g)

    if epoch % 5 == 0:
        if not os.path.exists("checkpoint"):
            os.mkdir("checkpoint")
        if not os.path.exists(os.path.join("checkpoint", opt.dataset)):
            os.mkdir(os.path.join("checkpoint", opt.dataset))
        net_g_model_out_path1 = "checkpoint/{}/netG_model_epoch_{}.pth".format(opt.dataset, epoch)
        torch.save(model_restoration,  net_g_model_out_path1)
        print("Checkpoint saved to {}".format("checkpoint" + opt.dataset))

    if epoch % 5 == 0:
        model_restoration.eval()
        with torch.no_grad():
            avg_psnr = 0.0;
            avg_ssim = 0.0
            for idx, (Rain, DeRain) in enumerate(test_loader):
                Rain_fft = torch.fft.fft2(Rain, dim=(-2, -1))
                Rain_amp = torch.abs(Rain_fft)
                Rain_phase = torch.angle(Rain_fft)

                output = model_restoration(Rain, Rain_amp,  Rain_phase)[1]

                im = output[0, :, :, :].clone()
                SavePicture.save_from_tensor_test(im[:, :, :]*255.0,   './Data/' + str(idx+1) + '.png')

                img = output[0, :, :, :].clone()
                img = img.float().cpu().numpy()

                img0 = DeRain[0, :, :, :].clone()
                img0 = img0.float().cpu().numpy()

                psnr = compare_psnr(img0, img, data_range=1.0)
                avg_psnr += psnr

                img22 = np.transpose(img, (1, 2, 0))
                img00 = np.transpose(img0,(1, 2, 0))
                ssim = compare_ssim(img22, img00, data_range=1.0, multichannel=True)
                avg_ssim += ssim

            print("===> Avg. PSNR: {:.6f} dB".format(avg_psnr / len(test_loader)))
            a.append(epoch);
            b.append(avg_psnr / len(test_loader));
            c.append(avg_ssim / len(test_loader));
        np.save("./Log/a.npy", a)
        np.save("./Log/b.npy", b)
        np.save("./Log/c.npy", c)
