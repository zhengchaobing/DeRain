import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init
import torch
import torch.nn as nn
from torch.nn import init
import functools
from torch.optim import lr_scheduler
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import torch
import math
from torch.nn import Module, Sequential, Conv2d, ReLU,AdaptiveMaxPool2d, AdaptiveAvgPool2d, \
    NLLLoss, BCELoss, CrossEntropyLoss, AvgPool2d, MaxPool2d, Parameter, Linear, Sigmoid, Softmax, Dropout, Embedding
from torch.nn import functional as F
from torch.autograd import Variable
torch_ver = torch.__version__[:3]
import torch.nn as nn
from guided_filter_pytorch.guided_filter import FastGuidedFilter, GuidedFilter
from TestTrans import Encoder_Trans
def conv(in_channels, out_channels, kernel_size, bias=True, padding=1, stride=1):
    return nn.Conv2d(in_channels, out_channels, kernel_size, padding=(kernel_size // 2), bias=bias, stride=stride)


## channel attention modules
class CALayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(CALayer, self).__init__()
        # global average pooling: feature --> point
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
            nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=True),
            nn.Sigmoid())

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv_du(y)
        return x * y

## spatial  attention
class spatial_attn_layer(nn.Module):
    def __init__(self, kernel_size=3):
        super(spatial_attn_layer, self).__init__()
        self.compress = ChannelPool()
        self.spatial = BasicConv(2, 1, kernel_size, stride=1, padding=(kernel_size - 1) // 2, relu=False)

    def forward(self, x):
        # import pdb;pdb.set_trace()
        x_compress = self.compress(x)
        x_out = self.spatial(x_compress)
        scale = torch.sigmoid(x_out)  # broadcasting
        return x * scale
        ##########################################################################

###BasicConv
class BasicConv(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1, groups=1, relu=True,
                 bn=False, bias=False):
        super(BasicConv, self).__init__()
        self.out_channels = out_planes
        self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding, dilation=dilation, groups=groups, bias=bias)
        self.bn = nn.BatchNorm2d(out_planes, eps=1e-5, momentum=0.01, affine=True) if bn else None
        self.relu = nn.ReLU() if relu else None

    def forward(self, x):
        x = self.conv(x)
        if self.bn is not None:
            x = self.bn(x)
        if self.relu is not None:
            x = self.relu(x)
        return x

###ChannelPool
class ChannelPool(nn.Module):
    def forward(self, x):
        return torch.cat((torch.max(x, 1)[0].unsqueeze(1), torch.mean(x, 1).unsqueeze(1)), dim=1)


class gaussian_attn_layer(nn.Module):
    def __init__(self):
        super(gaussian_attn_layer, self).__init__()
        n_feats  = 64
        self.Conv0 = conv(n_feats, n_feats, kernel_size=1, stride=1)

        self.Conv1 = conv(n_feats, n_feats, kernel_size=1, stride=1)

        self.Conv2 = conv(n_feats, n_feats, kernel_size=3, stride=1)
        self.Conv3 = conv(n_feats, n_feats, kernel_size=3, stride=1)

        self.Conv4 = conv(n_feats, n_feats, kernel_size=3, stride=1)
        self.Conv5 = conv(n_feats, n_feats, kernel_size=3, stride=1)

        self.Conv6 = conv(n_feats, n_feats, kernel_size=3, stride=1)
        self.Conv7 = conv(n_feats, n_feats, kernel_size=3, stride=1)

        self.ConvEND = conv(n_feats, 64, kernel_size=1, stride=1)
        self.prelu = nn.PReLU(64)
        self.sa = spatial_attn_layer()

    def forward(self,  x1):
        x = self.Conv0(x1)
        END = self.ConvEND(x)
        return END


## Dual Attention Block (DAB)
class DAB(nn.Module):
    def __init__(self, conv, n_feat, kernel_size, reduction, bias=True, bn=False, act=nn.ReLU(True)):

        super(DAB, self).__init__()
        modules_body = []
        for i in range(2):
            modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
            if bn: modules_body.append(nn.BatchNorm2d(n_feat))
            if i == 0: modules_body.append(act)

        self.SA = spatial_attn_layer()  ## Spatial Attention
        self.CA = CALayer(n_feat, reduction)  ## Channel Attention
        self.body = nn.Sequential(*modules_body)
        self.conv1x1 = nn.Conv2d(n_feat * 2, n_feat, kernel_size=1)

    def forward(self, x):
        res = self.body(x)
        sa_branch = self.SA(res)
        ca_branch = self.CA(res)
        res = torch.cat([sa_branch, ca_branch], dim=1)
        res = self.conv1x1(res)
        res += x
        return res

## Recursive Residual Group (RRG)

## Recursive Residual Group (RRG)
class RRG(nn.Module):
    def  __init__(self, conv, n_feat, kernel_size, reduction, act, num_dab):
        super(RRG, self).__init__()

        modules_body1=[conv(n_feat, n_feat, 1),nn.PReLU(64)]
        self.body1 = nn.Sequential(*modules_body1)
        modules_body3=[conv(n_feat, n_feat, 3),nn.PReLU(64)]
        self.body3 = nn.Sequential(*modules_body3)
        modules_body5=[conv(n_feat, n_feat, 5), nn.PReLU(64)]
        self.body5 = nn.Sequential(*modules_body5)

        modules_body=[conv(n_feat, n_feat, kernel_size)]
        self.body = nn.Sequential(*modules_body)

        modules_bodyA1 = [DAB(conv, n_feat, kernel_size, reduction, bias=True, bn=False, act=act)]
        self.bodyA1 = nn.Sequential(*modules_bodyA1)

        modules_bodyA3 = [DAB(conv, n_feat, kernel_size, reduction, bias=True, bn=False, act=act)]
        self.bodyA3 = nn.Sequential(*modules_bodyA3)

        modules_bodyA5 = [DAB(conv, n_feat, kernel_size, reduction, bias=True, bn=False, act=act)]
        self.bodyA5 = nn.Sequential(*modules_bodyA5)
    def forward(self, x):
        x1 = self.body1(x);   x3 = self.body3(x);    x5 = self.body5(x)
        A1 = self.bodyA1(x1); A3 = self.bodyA3(x3);  A5 = self.bodyA5(x5);
        res = A1 + A3 + A5
        res3 = self.body(res)
        res3 += x
        return res3



EPS = 1e-8


def weights_init_identity(m):
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        init.xavier_uniform_(m.weight.data)
    elif classname.find('InstanceNorm2d') != -1:
        init.constant_(m.weight.data, 1.0)
        init.constant_(m.bias.data,   0.0)


class AdaptiveNorm(nn.Module):
    def __init__(self, n):
        super(AdaptiveNorm, self).__init__()

        self.w_0 = nn.Parameter(torch.Tensor([1.0]))
        self.w_1 = nn.Parameter(torch.Tensor([0.0]))

        self.in_norm = nn.InstanceNorm2d(n, affine=True, track_running_stats=False)

    def forward(self, x):
        return self.w_0 * x + self.w_1 * self.in_norm(x)


def build_lr_net(norm=AdaptiveNorm, layer=5, width=24):#lr = low resolution
    layers = [
        nn.Conv2d(1, width, kernel_size=3, stride=1, padding=1, dilation=1, bias=False),
        norm(width),
        nn.LeakyReLU(0.2, inplace=True),
    ]

    for l in range(1, layer):
        layers += [nn.Conv2d(width,  width, kernel_size=3, stride=1, padding=2**l,  dilation=2**l,  bias=False),
                   norm(width),
                   nn.LeakyReLU(0.2, inplace=True)]

    layers += [
        nn.Conv2d(width, width, kernel_size=3, stride=1, padding=1, dilation=1, bias=False),
        norm(width),
        nn.LeakyReLU(0.2, inplace=True),
        nn.Conv2d(width,  1, kernel_size=1, stride=1, padding=0, dilation=1)
    ]

    net = nn.Sequential(*layers)
    net.apply(weights_init_identity)

    return net

class Enhance(nn.Module):
    def __init__(self, channels=3, num_of_layers=8):
        super(Enhance, self).__init__()
        n_feats = 64
        kernel_size = 3
        self.n_colors = 3

        InBlock1 = [conv(n_feats, n_feats, kernel_size=kernel_size, stride=1),
                    nn.PReLU(64),
                   RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=3)]
        self.inBlock1 = nn.Sequential(*InBlock1)
        InBlock2 = [conv(n_feats*2, n_feats, kernel_size=kernel_size, stride=1),
                    nn.PReLU(64),
                   RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=3)]
        self.inBlock2 = nn.Sequential(*InBlock2)

        # encoder1
        Encoder_first = [conv(n_feats, n_feats, kernel_size=kernel_size, stride=1),
                         nn.PReLU(64),
                         RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=3)]
        self.encoder_first = nn.Sequential(*Encoder_first)

        # encoder2
        Encoder_second = [conv(n_feats, n_feats, kernel_size=kernel_size, stride=1),
                          nn.PReLU(64),
                          RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=3)]
        self.encoder_second = nn.Sequential(*Encoder_second)

        # encoder3
        Encoder_third = [conv(n_feats, n_feats, kernel_size=kernel_size, stride=1),
                         nn.PReLU(64),
                         RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=3)]
        self.encoder_third = nn.Sequential(*Encoder_third)

        # encoder4
        Encoder_fourth = [conv(n_feats, n_feats, kernel_size=kernel_size, stride=1),
                          nn.PReLU(64),
                          RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=3)]
        self.encoder_fourth = nn.Sequential(*Encoder_fourth)

        OutBlock = [RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=3)]
        self.outBlock = nn.Sequential(*OutBlock)

        OutBlock2 = [conv(n_feats, 1, kernel_size=kernel_size, stride=1)]
        self.outBlock2 = nn.Sequential(*OutBlock2)

        self.gaussian_attn_layer = gaussian_attn_layer()
        #######################################################################################################################
        modules_head1 = [conv(1, 64, kernel_size=3, stride=1),
                         nn.PReLU(64),
                         Encoder_Trans()]
        self.head1 = nn.Sequential(*modules_head1)


    def forward(self,x_hr):
        xL = self.head1(x_hr)
        clear_features = torch.sum(xL, dim=0, keepdim=True)

        self.n_levels = 4
        self.scale = 0.5
        output = []
        for level in range(self.n_levels):
            scale = self.scale ** (self.n_levels - level - 1)
            n, c, h, w = x_hr.shape
            hi = int(round(h * scale))
            wi = int(round(w * scale))
            if level == 0:
                input_clear = F.interpolate(clear_features, (hi, wi), mode='bilinear')

                first_scale_inblock = self.inBlock1(input_clear)
            else:
                input_clear = F.interpolate(clear_features, (hi, wi), mode='bilinear')

                input_pred = F.interpolate(input_pre, (hi, wi), mode='bilinear')
                inp_all = torch.cat((input_clear, input_pred), 1)
                first_scale_inblock = self.inBlock2(inp_all)

            first_scale_encoder_first = self.encoder_first(first_scale_inblock);
            first_scale_encoder_second = self.encoder_second(first_scale_encoder_first)
            input_pre = self.outBlock( first_scale_encoder_second )

            out = self.outBlock2(input_pre).clamp(0.0, 1.0)
            output.append(out)
        return output




class E2EMEF(nn.Module):
    # end-to-end mef model
    def __init__(self, radius=1, eps=1e-4, is_guided=True):
        super(E2EMEF, self).__init__()
        self.lr = build_lr_net()
        self.is_guided = is_guided
        if is_guided:
            self.gf = FastGuidedFilter(radius, eps)

    def forward(self, x_lr, x_hr):
        w_lr = self.lr(x_lr)

        if self.is_guided:
            w_hr = self.gf(x_lr, w_lr, x_hr)
        else:
            w_hr = F.upsample(w_lr, x_hr.size()[2:], mode='bilinear')

        w_hr = torch.abs(w_hr)
        w_hr = (w_hr + EPS) / torch.sum((w_hr + EPS), dim=0)

        o_hr = torch.sum(w_hr * x_hr, dim=0, keepdim=True).clamp(0, 1)

        return o_hr, w_hr

    def init_lr(self, path):
        self.lr.load_state_dict(torch.load(path))
