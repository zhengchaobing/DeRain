# python相关
import cv2
import os
import sys
import platform
import time
import itertools
import numpy as np
import warnings
import argparse
from test_Demo import DeRainNet
# pytorh相关
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torch.nn.functional as F
from torch.utils import data
from torch.utils.data import DataLoader
from torch.autograd import Variable
import torch.distributed as dist
from torch.utils.checkpoint import checkpoint_sequential
from utils import save_img,calculate_0_distance,calculate_2_distance
from skimage.measure.simple_metrics import compare_psnr
from VGG import VGGLoss
# 自定义类
from config import get_arguments
import Dataset
import SavePicture
from networks import Enhance, get_scheduler, update_learning_rate
from utils import calculate_cos_distance,calculate_L1_L2_distance
#忽视警告
warnings.filterwarnings("ignore")
import random
# 导入参数设置
parser = get_arguments()
opt = parser.parse_args()

torch.manual_seed(opt.seed)
if opt.cuda:
    torch.cuda.manual_seed(opt.seed)
#并行训练相关设置
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device0=torch.device("cuda:0")

#读取数据集
train_dataset = Dataset.DatasetTrain(opt)
test_dataset  = Dataset.DatasetTest(opt)

batch_train = 8
batch_test  = 1
train_loader = data.DataLoader(dataset=train_dataset, batch_size=batch_train, shuffle=True,)
test_loader  = data.DataLoader(dataset=test_dataset,  batch_size=batch_test,  shuffle=False,)

step=1
model_path_L2H="checkpoint/{}/netG_model_epoch_{}.pth".format(opt.dataset, opt.nepochs)
print('===> Building models')
model_restoration = DeRainNet()
model_restoration = torch.nn.DataParallel(model_restoration)
if os.path.exists(model_path_L2H):
    print('===> Success load model_L2H models')
    model_restoration = torch.load(model_path_L2H)
    opt.epoch_count=opt.nepochs+1
model_restoration.to(torch.device('cuda'))
vgg_loss = VGGLoss().to(torch.device('cuda'))
cos_loss = calculate_cos_distance().to(torch.device('cuda'))

l0 = calculate_0_distance().to(device0)
l2 = calculate_2_distance().to(device0)

criterionL1  = nn.L1Loss().to(device0)
# setup optimizer
optimizer_g = optim.Adam(model_restoration.parameters(), lr=opt.lr, betas=(opt.beta1, 0.999))
net_g_scheduler = get_scheduler(optimizer_g, opt)

a = [];
b = [];
c = [];
if os.path.exists('a.npy'):
    a = np.load("a.npy").tolist()
if os.path.exists('b.npy'):
    b = np.load("b.npy").tolist()
if os.path.exists('c.npy'):
    c = np.load("c.npy").tolist()
for epoch in range(opt.epoch_count, opt.niter + opt.niter_decay + 1):
    # train
    model_restoration.train()
    for idx ,(mid, vlow , low, weightbinarylow, vhig, hig, weightbinaryhig) in enumerate(train_loader):
        n = random.randint(1, batch_train-1)
        low[0:n] = hig[0:n];
        vlow[0:n] = vhig[0:n];
        weightbinarylow[0:n] = weightbinaryhig[0:n];
        optimizer_g.zero_grad()
        output = model_restoration(mid / 255.0, vlow / 255.0, weightbinarylow)

        # loss = criterionL1(output, low / 255.0)
        mask0 = l0(mid[n:batch_train], 250.0)
        mask2 = l2(mid[0:n],  5.0)

        loss_feature = vgg_loss(output, low / 255.0) * 0.01
        loss_color = cos_loss(output, low / 255.0) * 0.1
        loss1 = 1.0 * criterionL1(mask0 * output[n:batch_train], mask0 * (low[n:batch_train]/255.0)) + \
                1.0 * criterionL1(mask2 * output[0:n], mask2 * (low[0:n] / 255.0))
        loss = loss_feature + loss_color + loss1
        loss.backward()
        optimizer_g.step()
        print("===> Epoch[{}]({}/{}): Loss: {:.4f} Loss1: {:.4f} ".format(epoch,idx, len(train_loader),loss.item(), loss1.item()))
    update_learning_rate(net_g_scheduler, optimizer_g)
    #checkpoint, Loss.item()

    if epoch % 10 == 0:
        if not os.path.exists("checkpoint"):
            os.mkdir("checkpoint")
        if not os.path.exists(os.path.join("checkpoint", opt.dataset)):
            os.mkdir(os.path.join("checkpoint", opt.dataset))
        net_g_model_out_path = "checkpoint/{}/netG_model_epoch_{}.pth".format(opt.dataset, epoch)
        torch.save(model_restoration, net_g_model_out_path)
        print("Checkpoint saved to {}".format("checkpoint" + opt.dataset))

    if epoch % 10 == 0:
        model_restoration.eval()
        with torch.no_grad():
            avg_psnr = 0.0;  avg_psnr2 = 0.0
            for idx, (mid, vlow , low, weightbinarylow, vhig, hig, weightbinaryhig) in enumerate(test_loader):
                output_L = model_restoration(mid / 255.0, vlow / 255.0, weightbinarylow)
                output_H = model_restoration(mid / 255.0, vhig / 255.0, weightbinaryhig)

                SavePicture.save_from_tensor_test(output_L[0, :, :, :] * 255.0, './dataset/Low/' + str(idx+1) + '.png')
                SavePicture.save_from_tensor_test(output_H[0, :, :, :] * 255.0, './dataset/Hig/' + str(idx + 1) + '.png')

                img = output_L[0, :, :, :].clone();     img = img.float().cpu().numpy()
                img0 = low[0, :, :, :].clone()/255.0; img0 = img0.float().cpu().numpy()
                psnr = compare_psnr(img0, img, data_range=1.0)
                avg_psnr += psnr

                img2 = output_H[0, :, :, :].clone();   img2 = img2.float().cpu().numpy()
                img3 = hig[0, :, :, :].clone()/255.0;  img3 = img3.float().cpu().numpy()
                psnr2 = compare_psnr(img2, img3, data_range=1.0)
                avg_psnr2 += psnr2

            print("===> Avg. PSNR: {:.6f} dB".format(avg_psnr / len(test_loader)))
            a.append(epoch);
            b.append(avg_psnr  / len(test_loader));
            c.append(avg_psnr2 / len(test_loader));
        np.save("a.npy", a)
        np.save("b.npy", b)
        np.save("c.npy", c)


